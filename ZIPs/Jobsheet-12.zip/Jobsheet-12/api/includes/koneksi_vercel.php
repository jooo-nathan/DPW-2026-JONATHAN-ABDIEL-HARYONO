<?php
// Koneksi khusus Vercel + Neon (dipakai otomatis oleh koneksi.php kalau DATABASE_URL ada).
// Bagian ini konfigurasi deploy, bukan materi inti: alamat database diambil dari Environment Variable.
// Di Vercel: alamat database sudah tersimpan di Environment Variable bernama DATABASE_URL
// (bentuknya: postgres://user:password@host/nama_db). parse_url() memecahnya jadi bagian-bagian.
$dbUrl = getenv('DATABASE_URL');
// Ambil hanya bagian postgres://... (jaga-jaga kalau ikut tersalin kata "psql" atau tanda kutip)
if (!$dbUrl || !preg_match('~postgres(?:ql)?://[^\s\'"]+~', $dbUrl, $cocok)) {
    die("DATABASE_URL belum terbaca atau bentuknya salah. Harus berupa postgresql://user:password@host/nama_db");
}
$url  = parse_url($cocok[0]);
$host = $url['host'];
$port = $url['port'] ?? "5432";
$db   = ltrim($url['path'], '/');
$user = urldecode($url['user']);
$pass = urldecode($url['pass']);


// Neon perlu tahu nama "endpoint"-nya (bagian pertama dari alamat host, tanpa "-pooler").
// Library PostgreSQL di Vercel belum mengirimnya otomatis, jadi kita kirim lewat "options".
$opsi = "";
if (strpos($host, "neon.tech") !== false) {
    $endpoint = str_replace("-pooler", "", explode(".", $host)[0]);
    $opsi = ";options='endpoint=$endpoint'";
}

try {
    // sslmode=require: database online mewajibkan koneksi terenkripsi
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$db;sslmode=require$opsi", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal (host: $host): " . $e->getMessage());
}
